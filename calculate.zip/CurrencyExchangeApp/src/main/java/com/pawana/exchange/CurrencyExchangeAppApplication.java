package com.pawana.exchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyExchangeAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchangeAppApplication.class, args);
	}

}
