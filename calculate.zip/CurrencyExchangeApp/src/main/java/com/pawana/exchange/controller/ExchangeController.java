package com.pawana.exchange.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pawana.exchange.entity.Exchange;
import com.pawana.exchange.service.ExchangeService;

@RestController
@RequestMapping("/api")
public class ExchangeController {
	
	@Autowired
	private ExchangeService service;
	
	@PostMapping("/exchange")
	public Exchange addExchange(@RequestBody Exchange exchange) {
		
		return service.addorUpdateExchange(exchange);
		
	}
	
	@GetMapping("/exchange/source/{source}/destination/{destination}")
	public Exchange getExchange(@PathVariable("source") String source,@PathVariable("destination") String destination) {
		
		return service.getExchange(source, destination);
		
	}

	

}
