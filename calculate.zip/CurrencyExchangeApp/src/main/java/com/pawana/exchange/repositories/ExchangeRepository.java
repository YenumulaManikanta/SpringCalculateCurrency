package com.pawana.exchange.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pawana.exchange.entity.Exchange;

public interface ExchangeRepository extends JpaRepository<Exchange, Long> {
	
	public Exchange findBySourceAndDestination(String source,String destination);
	
	

}
