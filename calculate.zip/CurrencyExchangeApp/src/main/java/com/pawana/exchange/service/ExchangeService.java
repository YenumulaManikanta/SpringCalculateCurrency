package com.pawana.exchange.service;

import com.pawana.exchange.entity.Exchange;

public interface ExchangeService {
	
	public Exchange addorUpdateExchange(Exchange exchange);
	
	public Exchange getExchange(String source,String destination);

}
