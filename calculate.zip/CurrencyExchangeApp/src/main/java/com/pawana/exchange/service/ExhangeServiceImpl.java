package com.pawana.exchange.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pawana.exchange.entity.Exchange;
import com.pawana.exchange.repositories.ExchangeRepository;

@Service
public class ExhangeServiceImpl implements ExchangeService {
	
	@Autowired
	private ExchangeRepository exchangeRepository;

	@Override
	public Exchange addorUpdateExchange(Exchange exchange) {
		return exchangeRepository.save(exchange);
	}

	@Override
	public Exchange getExchange(String source, String destination) {
		return exchangeRepository.findBySourceAndDestination(source, destination);
	}

}
